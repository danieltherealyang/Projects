#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameWorld.h"
#include <string>

using namespace std;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
// add public/private functions and only private data members
// must NOT also have x or y member variables, but instead use these functions and
// moveTo() from the GraphObject base class.
// MUST NOT store an imageId value or any value somehow
// related/derived from the imageID value in any way

/* Hierarchy
Actor
    Bonkable
        Block
    Peach
*/

class StudentWorld;

class Actor : public GraphObject {
    public:
        Actor(int imageID, int startX, int startY, int dir, int depth, double size, bool alive, int health, StudentWorld* gameWorld) : 
            GraphObject(imageID, startX, startY, dir, depth, size), m_alive(alive), m_health(health), m_gameWorld(gameWorld) {};
        virtual void doSomething() = 0;
        bool doesOverlap(int x, int y) {
            if (getX() > x + SPRITE_WIDTH - 1 ||
            getX() + SPRITE_WIDTH - 1 < x ||
            getY() > y + SPRITE_HEIGHT - 1 ||
            getY() + SPRITE_HEIGHT - 1 < y)
                return false;
            return true;
        }
        void setAlive(bool alive) {m_alive = alive;}
        bool getAlive() {return m_alive;}
        void setHealth(int health) {m_health = health;}
        int getHealth() {return m_health;}
        StudentWorld* getWorld() {return m_gameWorld;}
    private:
        StudentWorld* m_gameWorld;
        bool m_alive;
        int m_health;
        bool m_damageable;
};

class Bonkable : public Actor {
    public:
        Bonkable(int imageID, int startX, int startY, int dir, int depth, double size, bool alive, int health, StudentWorld* gameWorld) :
            Actor(imageID, startX, startY, dir, depth, size, alive, health, gameWorld) {};
        virtual void bonk() = 0;
};

class Block : public Bonkable {
    public:
        Block(int startX, int startY, string goodie, StudentWorld* gameWorld);
        virtual void doSomething();
        virtual void bonk();
        bool isDamageable() {return false;}
    private:
        //Types: None, Star, Flower, Mushroom
        string m_goodie; //use health to check if released, unneeded for part 1
        
};

class Peach : public Actor {
    public:
        Peach(int startX, int startY, StudentWorld* gameWorld);
        virtual void doSomething();
    private:
        bool m_invincible = false; bool m_temp = false;
        int m_ticks = 0;
        int m_rechargeTicks = 0;
        int m_remainingJumpDist = 0;
};

#endif // ACTOR_H_
