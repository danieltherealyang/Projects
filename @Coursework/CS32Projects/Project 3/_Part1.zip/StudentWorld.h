#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include "Level.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
    public:
        StudentWorld(std::string assetPath); //never call these three functions
        ~StudentWorld();
        virtual int init(); //initializes each level: game start, new level, restart level
        virtual int move(); //20x per second, updating game actors, introduce new actors, delete actors
        virtual void cleanUp(); //current level or loses a life, free all actors, 

        void addPeach(int x, int y); //x and y take in level data coords
        void addKoopa(int x, int y) {};
        void addGoomba(int x, int y) {};
        void addPiranha(int x, int y) {};
        void addBlock(int x, int y);
        void addStarGoodieBlock(int x, int y) {};
        void addMushroomGoodieBlock(int x, int y) {};
        void addFlowerGoodieBlock(int x, int y) {};
        void addPipe(int x, int y) {};
        void addFlag(int x, int y) {};
        void addMario(int x, int y) {};

        bool notBlocked(int x, int y, Bonkable*& object); //x and y are pixel coords
        bool notBlocked(int x, int y);
    private:
        vector<Bonkable*> actors;
        Peach* m_Peach;
};

#endif // STUDENTWORLD_H_
