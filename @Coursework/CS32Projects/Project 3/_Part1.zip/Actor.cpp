#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

// TODO: 5, 6, 7, other
Peach::Peach(int startX, int startY, StudentWorld* gameWorld) :
Actor(IID_PEACH, startX, startY, 0, 0, 1, true, 1, gameWorld) {
    //no invincibility, no powers
}

void Peach::doSomething() {
    //1
    if (!getAlive())
        return;
    //2
    if (m_invincible) {
        m_ticks--;
        if (m_ticks == 0)
            m_invincible = false;
    }
    //3
    if (m_temp && m_invincible) {
        m_ticks--;
        if (m_ticks == 0) {
            m_invincible = false;
            m_temp = false;
        }
    }
    //4
    if (m_rechargeTicks > 0) {
        m_rechargeTicks--;
    }
    //5
    Bonkable* object;
    if (!getWorld()->notBlocked(getX(), getY(), object))
        object->bonk();
    //6
    if (m_remainingJumpDist > 0) {
        int targetY = getY() + 4;
        if (!getWorld()->notBlocked(getX(), targetY, object)) {
            object->bonk();
            m_remainingJumpDist = 0;
        } else {
            moveTo(getX(), targetY);
            m_remainingJumpDist--;
        }
    }
    //7
    if (m_remainingJumpDist == 0 && getWorld()->notBlocked(getX(), getY() - 4)) {
        moveTo(getX(), getY() - 4);
    }
    //end
    int key;
    if (getWorld()->getKey(key)) {
        if (key == KEY_PRESS_LEFT) {
            setDirection(180);
            int targetX = getX() - 4;
            if (getWorld()->notBlocked(targetX, getY(), object)) {
                moveTo(targetX, getY());
            } else {
                object->bonk();
            }
        }
        if (key == KEY_PRESS_RIGHT) {
            setDirection(0);
            int targetX = getX() + 4;
            if (getWorld()->notBlocked(targetX, getY(), object)) {
                moveTo(targetX, getY());
            } else {
                object->bonk();
            }
        }
        if (key == KEY_PRESS_UP) {
            if (!getWorld()->notBlocked(getX(), getY() - 1)) { //if object below
                m_remainingJumpDist = 8; //true if has jump power
                getWorld()->playSound(SOUND_PLAYER_JUMP);
            }
        }
        if (key == KEY_PRESS_SPACE) {
            if (true || m_rechargeTicks > 0) //no shoot power or recharging
                return;
            getWorld()->playSound(SOUND_PLAYER_FIRE);
            m_rechargeTicks = 8;
            int targetX;
            if (getDirection() == 0)
                targetX = getX() + 4;
            else if (getDirection() == 180)
                targetX = getX() - 4;
            //create fireball, set direction
        }
    }
}

Block::Block(int startX, int startY, string goodie, StudentWorld* gameWorld) :
Bonkable(IID_BLOCK, startX, startY, 0, 2, 1, true, 1, gameWorld),
m_goodie(goodie) {
}

void Block::doSomething() {
}

void Block::bonk() {
    if (m_goodie == "None" || getHealth() == 0) {
        getWorld()->playSound(SOUND_PLAYER_BONK);
    } else {
        getWorld()->playSound(SOUND_POWERUP_APPEARS);
        int targetY = getY() + 8;
        //introduce goodie at x,targetY
        setHealth(0);
    }
}
