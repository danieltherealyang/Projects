#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}

StudentWorld::~StudentWorld() {
    cleanUp();
}

int StudentWorld::init()
{
    // 1. Initialize the data structures used to keep track of your game’s world.
    // 2. Allocate and insert a Peach object into the game world. Every time a level starts
    // or restarts, Peach starts out fully initialized (with the no special powers active,
    // etc.) in her initial location as specified by the current level data file.
    // 3. Allocate and insert all of the blocks, pipes, flags, enemies and Mario into the
    // game world as described below.
    // Store data in a single STL representation, separate pointer to Peach object, everything
    // else stored together.
    // Can initialize other StudentWorld member variables.
    // Load information from data file into level object and populate with objects at correct locations.
    // Return GWSTATUS_LEVEL_ERROR if no data file exists or file improperly formatted
    Level level(assetPath());
    ostringstream oss;
    oss << "level";

    if (getLevel() < 10)
        oss << 0 << getLevel() << ".txt";
    else if (getLevel() >= 10)
        oss << getLevel() << ".txt";
    else
        return GWSTATUS_LEVEL_ERROR;
    
    string level_file = oss.str();

    Level::LoadResult result = level.loadLevel(level_file);
    if (result == Level::load_fail_file_not_found) {
        cerr <<  "Could not find " << level_file << " data file" << endl;
        return GWSTATUS_LEVEL_ERROR;
    } else if (result == Level::load_fail_bad_format) {
        cerr << level_file << " is improperly formatted" << endl;
        return GWSTATUS_LEVEL_ERROR;
    } else if (result == Level::load_success) {
        cerr << "Successfully loaded level" << endl;
        Level::GridEntry ge;
        
        for (int x = 0; x < 32; x++) {
            for (int y = 0; y < 32; y++) {
                ge = level.getContentsOf(x, y);
                switch (ge) {
                    case Level::empty:
                        cerr << "Location " << x << "," << y << " is empty" << endl;
                        break;
                    case Level::peach:
                        cerr << "Location " << x << "," << y << " is where Peach starts" << endl;
                        addPeach(x, y);
                        break;
                    case Level::koopa:
                        cerr << "Location " << x << "," << y << " starts with a koopa" << endl;
                        break;
                    case Level::goomba:
                        cerr << "Location " << x << "," << y << " starts with a goomba" << endl;
                        break;
                    case Level::piranha:
                        cerr << "Location " << x << "," << y << " starts with a piranha" << endl;
                        break;
                    case Level::block:
                        cerr << "Location " << x << "," << y << " holds a regular block" << endl;
                        addBlock(x, y);
                        break;
                    case Level::star_goodie_block:
                        cerr << "Location " << x << "," << y << " has a star goodie block" << endl;
                        break;
                    case Level::mushroom_goodie_block:
                        cerr << "Location " << x << "," << y << " has a mushroom goodie block" << endl;
                        break;
                    case Level::flower_goodie_block:
                        cerr << "Location " << x << "," << y << " has a flower goodie block" << endl;
                        break;
                    case Level::pipe:
                        cerr << "Location " << x << "," << y << " holds a pipe block" << endl;
                        break;
                    case Level::flag:
                        cerr << "Location " << x << "," << y << " is where a flag is" << endl;
                        break;
                    case Level::mario:
                        cerr << "Location " << x << "," << y << " is where mario is" << endl;
                        break;
                    default:
                        cerr << "GridEntry not found" << endl;
                }
            }
        }
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    m_Peach->doSomething();

    vector<Bonkable*>::iterator it = actors.begin();
    while (it != actors.end()) {
        (*it)->doSomething();
        it++;
    }

    if (!m_Peach->getAlive()) {
        playSound(SOUND_PLAYER_DIE);
        decLives();
        return GWSTATUS_PLAYER_DIED;
    }

    //reach flag, finished level
    //reach mario, finished game

    it = actors.begin();
    while (it != actors.end()) {
        if (!(*it)->getAlive()) {
            delete *it;
            it = actors.erase(it);
        }
        it++;
    }

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    vector<Bonkable*>::iterator it = actors.begin();
    while (it != actors.end()) {
        delete *it;
        it++;
    }
    actors.clear();
    delete m_Peach;
}

void StudentWorld::addPeach(int x, int y) {
    m_Peach = new Peach(x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this);
}

void StudentWorld::addBlock(int x, int y) {
    actors.push_back(new Block(x * SPRITE_WIDTH, y * SPRITE_HEIGHT, "None", this));
}

bool StudentWorld::notBlocked(int x, int y, Bonkable*& object) {
    vector<Bonkable*>::iterator it = actors.begin();
    while (it != actors.end()) {
        if ((*it)->doesOverlap(x, y)) {
            object = *it;
            return false;
        }
        it++;
    }
    return true;
}

bool StudentWorld::notBlocked(int x, int y) {
    vector<Bonkable*>::iterator it = actors.begin();
    while (it != actors.end()) {
        if ((*it)->doesOverlap(x, y)) {
            return false;
        }
        it++;
    }
    return true;
}